-- Query 1: display all transactions for a batch (filter: merchant_id + batch_date + batch_ref_num)
-- TODO: implement me

-- Query 2: display statistics for a batch (filter: merchant_id + batch_date + batch_ref_num)
--          grouped by transaction card type
-- TODO: implement me

-- Query 3: display top 10 merchants (by total amount) for a given date range (batch_date)
--          merchant id, merchant name, total amount, number of transactions
-- TODO: implement me
